s=4**2020+2**2017-15
b=bin(s)[2:]
print(b.count('1'))
